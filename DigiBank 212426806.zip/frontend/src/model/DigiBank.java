package model;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@SessionScoped
@ManagedBean(name="digibank")
public class DigiBank {
	
	private String name;
	private String sourcePassport;
	private String destinationBank;
	private String destinationCountry;
	private String accountNumber;
	private Double amount;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSourcePassport() {
		return sourcePassport;
	}
	public void setSourcePassport(String sourcePassport) {
		this.sourcePassport = sourcePassport;
	}
	public String getDestinationBank() {
		return destinationBank;
	}
	public void setDestinationBank(String destinationBank) {
		this.destinationBank = destinationBank;
	}
	public String getDestinationCountry() {
		return destinationCountry;
	}
	public void setDestinationCountry(String destinationCountry) {
		this.destinationCountry = destinationCountry;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	public DigiBankEntity getEntity()
	{
		DigiBankEntity digibankentity = new DigiBankEntity();
		
		Long id = (long) 0; //Initializing our id variable to null 
		digibankentity.setId(id);
		digibankentity.setName(name);
		digibankentity.setAccountNumber(accountNumber);
		digibankentity.setAmount(amount);
		digibankentity.setDestinationBank(destinationBank);
		digibankentity.setDestinationCountry(destinationCountry);
		digibankentity.setSourcePassport(sourcePassport);
		
		return digibankentity;
	}
	

	
}
