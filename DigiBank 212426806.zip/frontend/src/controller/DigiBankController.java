package controller;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import model.DigiBank;
import service.DigiBankEJB; 

@SessionScoped
@ManagedBean(name="digibankcontroller")
public class DigiBankController {
	
	@EJB
	DigiBankEJB digibankservice;
	@ManagedProperty(value="#{digibank}")
	private DigiBank digibank;
	
	public void addNewTransaction()
	{
		System.out.println("Fumani your doing good!");
		digibankservice.addNew(digibank.getEntity());
	}
	
	public DigiBank getDigibank() {
		return digibank;
	}

	public void setDigibank(DigiBank digibank) {
		this.digibank = digibank;
	}

	

}
