package service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import model.DigiBankEntity;

/**
 * Session Bean implementation class DigiBankEJB
 */
@Stateless
@LocalBean
public class DigiBankEJB {

	@PersistenceContext
    private EntityManager em;
    
    public DigiBankEJB() {
        // TODO Auto-generated constructor stub
    }
    
    public void addNew(DigiBankEntity digibankentity)
    {
    	System.out.println("***************Adding the following Transaction to DigiBank Database***************");
    	em.persist(digibankentity);
    	
    }

}
